﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Italian language file.
 *
 * Author: Marco (marco.romanelli@protonmail.ch)
 */

 theUILang.bulkCopy		= "Copia";
 theUILang.Magnet		= "Collegamento magnet";
 theUILang.bulkAdd		= "Caricamento in serie"; 
 theUILang.bulkAddDescription	= "Un collegamento per riga (HTTP, magnet o hash)";

thePlugins.get("bulk_magnet").langLoaded();