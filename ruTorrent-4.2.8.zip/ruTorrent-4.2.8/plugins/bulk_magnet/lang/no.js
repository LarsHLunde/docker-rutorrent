﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Norwegian language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Kopier";
 theUILang.Magnet		= "Magnet-lenke";
 theUILang.bulkAdd		= "Bulk-lasting"; 
 theUILang.bulkAddDescription	= "En lenke per linje (HTTP, magnet-lenke eller hash)";

thePlugins.get("bulk_magnet").langLoaded();