﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Copiar";
 theUILang.Magnet		= "Magnet link";
 theUILang.bulkAdd		= "Carregamento em massa"; 
 theUILang.bulkAddDescription	= "Um link por linha (HTTP, magnet-link ou hash)";

thePlugins.get("bulk_magnet").langLoaded();