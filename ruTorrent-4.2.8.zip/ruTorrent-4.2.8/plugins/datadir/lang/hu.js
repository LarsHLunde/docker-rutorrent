/*
 * PLUGIN DATADIR
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Mentés a";
 theUILang.DataDirMove		= "Adatok áthelyezése";
 theUILang.datadirDlgCaption	= "Torrent adatok könyvtára";
 theUILang.datadirDirNotFound	= "DataDir plugin: Érvénytelen könyvtár";
 theUILang.datadirSetDirFail	= "DataDir plugin: Művelet sikertelen";

thePlugins.get("datadir").langLoaded();
