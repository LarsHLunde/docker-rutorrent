﻿/*
 * PLUGIN DATADIR
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.DataDir		= "Şuraya kaydet";
 theUILang.DataDirMove		= "Veri dosyalarını taşı";
 theUILang.datadirDlgCaption	= "Torrent Veri Dizini";
 theUILang.datadirDirNotFound	= "DataDir Eklentisi: Geçersiz dizin";
 theUILang.datadirSetDirFail	= "DataDir Eklentisi: İşlem başarısız";

thePlugins.get("datadir").langLoaded();
