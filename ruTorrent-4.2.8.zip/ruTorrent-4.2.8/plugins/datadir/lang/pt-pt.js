﻿/*
 * PLUGIN DATADIR
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Guardar em";
 theUILang.DataDirMove		= "Mover ficheiros de dados";
 theUILang.datadirDlgCaption	= "Diretório de dados";
 theUILang.datadirDirNotFound	= "DataDir plugin: Diretório inválido";
 theUILang.datadirSetDirFail	= "DataDir plugin: Falha na operação";

thePlugins.get("datadir").langLoaded();