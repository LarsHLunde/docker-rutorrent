﻿/*
 * PLUGIN DATADIR
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.DataDir		= "Lagre til";
 theUILang.DataDirMove		= "Flytt datafiler";
 theUILang.datadirDlgCaption	= "Torrent-datamappe";
 theUILang.datadirDirNotFound	= "DataDir-plugin: Ugyldig mappe";
 theUILang.datadirSetDirFail	= "DataDir-plugin: Operasjonsfeil";

thePlugins.get("datadir").langLoaded();