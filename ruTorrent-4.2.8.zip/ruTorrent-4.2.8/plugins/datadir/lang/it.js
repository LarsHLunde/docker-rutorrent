﻿/*
 * PLUGIN DATADIR
 *
 * Italian language file.
 *
 * Author: Gianni
 * Author: Marco (marco.romanelli@protonmail.ch)
 */

 theUILang.DataDir		= "Salva in";
 theUILang.DataDirMove		= "Sposta i file dati";
 theUILang.datadirDlgCaption	= "Cartella dati del torrent";
 theUILang.datadirDirNotFound	= "Plugin 'DataDir': Cartella non valida";
 theUILang.datadirSetDirFail	= "Plugin 'DataDir': Operazione fallita";

thePlugins.get("datadir").langLoaded();
