/*
 * PLUGIN CHECK_PORT
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.checkWebsiteNotFound = "Check_port bővítmény: Bővítmény nem fog működni. Érvénytelen konfiguráció";
 theUILang.checkPort		= "Port állapotának ellenőrzése";
 theUILang.portStatus		= [
 				  "Port állapota ismeretlen",
 				  "Port zárva van",
 				  "Port nyitva van"
 				  ];

thePlugins.get("check_port").langLoaded();
