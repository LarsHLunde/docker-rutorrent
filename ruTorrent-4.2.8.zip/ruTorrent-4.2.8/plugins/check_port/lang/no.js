﻿/*
 * PLUGIN CHECK_PORT
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.checkWebsiteNotFound = "Check_port-plugin: Plugin vil ikke virke. Ugyldig oppsett";
 theUILang.checkPort		= "Sjekk portstatus";
 theUILang.portStatus		= [
 				  "Portstatus er ukjent",
 				  "Port er lukket",
 				  "Port er åpen"
 				  ];

thePlugins.get("check_port").langLoaded();