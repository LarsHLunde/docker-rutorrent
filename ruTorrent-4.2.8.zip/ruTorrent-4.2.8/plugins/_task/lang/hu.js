/*
 * PLUGIN _TASK
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Folyamatban...";
 theUILang.tskCommandDone	= "Kész.";
 theUILang.tskConsole		= "Konzol";
 theUILang.tskErrors		= "Diagnosztika";
 theUILang.tskBackground	= "Elrejtés";
 theUILang.tskStart		= "Elindult";
 theUILang.tskFinish		= "Végzett";
 theUILang.tskElapsed		= "Eltelt";
 theUILang.tskPlugin		= "Bővítmény";
 theUILang.tskDeletePrompt	= "Tényleg törölni szeretné a kiválasztott feladato(ka)t?";
 theUILang.tskDelete		= "Feladat(ok) törlése";
 theUILang.tskActivate		= "Bekapcsolás";
 theUILang.tskRemove		= "Törlés";
 theUILang.tskRefresh		= "Frissítés";
 theUILang.tskRunning		= "Folyamatban";
 theUILang.tskArg		= "Paraméter";
 theUILang.tskTasks		= "Feladatok";

thePlugins.get("_task").langLoaded();
