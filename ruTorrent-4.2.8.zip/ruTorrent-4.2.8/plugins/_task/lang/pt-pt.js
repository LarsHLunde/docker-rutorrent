﻿/*
 * PLUGIN _TASK
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Em execução...";
 theUILang.tskCommandDone	= "Feito.";
 theUILang.tskConsole		= "Consola";
 theUILang.tskErrors		= "Diagnóstico";
 theUILang.tskBackground	= "Ocultar";
 theUILang.tskStart		= "Iniciado";
 theUILang.tskFinish		= "Terminado";
 theUILang.tskElapsed		= "Decorrido";
 theUILang.tskPlugin		= "Plugin";
 theUILang.tskDeletePrompt	= "Queres realmente remover a(s) tarefa(s) marcada(s)?";
 theUILang.tskDelete		= "Remover tafera(s)";
 theUILang.tskActivate		= "Atitar";
 theUILang.tskRemove		= "Remover";
 theUILang.tskRefresh		= "Atualizar";
 theUILang.tskRunning		= "Em execução";
 theUILang.tskArg		= "Parametro";
 theUILang.tskTasks		= "Tarefas";

thePlugins.get("_task").langLoaded();