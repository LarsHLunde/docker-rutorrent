﻿/*
 * PLUGIN EDIT
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.EditTrackers			= "Editar Torrent...";
 theUILang.EditTorrentProperties	= "Propriedades do Torrent";
 theUILang.errorAddTorrent		= "Erro ao adicionar ficheiro torrent";
 theUILang.errorWriteTorrent		= "Erro ao escrever ficheiro torrent";
 theUILang.errorReadTorrent		= "Erro ao ler ficheiro torrent";
 theUILang.cantFindTorrent		= "Ficheiro torrent fonte para esta descarga não encontrado."

thePlugins.get("edit").langLoaded();