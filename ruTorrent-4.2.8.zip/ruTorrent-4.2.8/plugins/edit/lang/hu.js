/*
 * PLUGIN EDIT
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.EditTrackers			= "Torrent szerkesztése...";
 theUILang.EditTorrentProperties	= "Torrent tulajdonságok";
 theUILang.errorAddTorrent		= "Hiba torrent fájl hozzáadása közben";
 theUILang.errorWriteTorrent		= "Hiba a torrent fájl írása során";
 theUILang.errorReadTorrent		= "Hiba a torrent fájl olvasásakor";
 theUILang.cantFindTorrent		= "A letöltés forrás torrent fájlja nem található."

thePlugins.get("edit").langLoaded();
