﻿/*
 * PLUGIN CHUNKS
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Blocos";
 theUILang.cAvail		= "Disponibilidade";
 theUILang.cDownloaded		= "Descarregados";
 theUILang.cMode		= "Modo";
 theUILang.chunksCount		= "Contagem de blocos";
 theUILang.chunkSize		= "Tamanho dos bloco";
 theUILang.cLegend		= "Legenda";
 theUILang.cLegendVal		= [ "4 blocos por célula", "1 bloco por célula" ];

thePlugins.get("chunks").langLoaded();