﻿/*
 * PLUGIN DISKSPACE
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "Aviso! O disco está cheio. O rTorrent pode não funcionar corretamente e nenhum dado será descarregado até espaço em disco ser libertado.";

thePlugins.get("diskspace").langLoaded();