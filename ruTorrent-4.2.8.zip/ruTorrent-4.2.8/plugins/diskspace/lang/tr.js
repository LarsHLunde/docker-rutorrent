﻿/*
 * PLUGIN DISKSPACE
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.diskNotification	= "Uyarı! Disk dolu. rTorrent düzgün çalışmayabilir ve siz biraz disk alanı boşaltana kadar hiçbir veri indirilmeyecektir.";

thePlugins.get("diskspace").langLoaded();
