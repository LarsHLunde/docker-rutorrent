﻿/*
 * PLUGIN DISKSPACE
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.diskNotification	= "Advarsel! Disken er full. rTorrent vil kanskje feile. Ingen data blir lastest ned før du frigjør diskplass.";

thePlugins.get("diskspace").langLoaded();