﻿/*
 * PLUGIN DISKSPACE
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.diskNotification	= "Warnung! Die Festplatte ist voll. Es könnte sein, dass rTorrent nicht ordnungsgemäß funktioniert und es werden keine Daten heruntergeladen, bis Speicherplatz freigeben wird.";

thePlugins.get("diskspace").langLoaded();