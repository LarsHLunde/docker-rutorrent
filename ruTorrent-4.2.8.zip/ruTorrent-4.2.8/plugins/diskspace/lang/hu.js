/*
 * PLUGIN DISKSPACE
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "Figyelem! A lemez megtelt. Az rTorrent nem fog megfelelően futni, és addig nem töltődnek le adatok, amíg nem szabadít fel némi helyet a lemezen.";

thePlugins.get("diskspace").langLoaded();
