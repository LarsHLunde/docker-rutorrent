﻿/* PLUGIN _CLOUDFLARE
 *
 * Italian language file.
 *
 * Author: Marco (marco.romanelli@protonmail.ch)
 */

 theUILang.cannotLoadCloudscraper		= "plugin '_cloudflare': il modulo 'cloudscraper' per Python non può essere caricato";

thePlugins.get("_cloudflare").langLoaded();
