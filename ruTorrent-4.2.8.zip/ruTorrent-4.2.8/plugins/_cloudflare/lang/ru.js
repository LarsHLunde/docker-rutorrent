﻿/* PLUGIN _CLOUDFLARE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "Плагин _cloudflare: Python не может загрузить модуль cloudscraper";

thePlugins.get("_cloudflare").langLoaded();
