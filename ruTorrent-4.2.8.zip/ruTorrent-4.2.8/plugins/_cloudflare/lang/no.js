﻿/* PLUGIN _CLOUDFLARE
 *
 * Norwegian language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare plugin: cloudscraper-modulen kunne ikke lastes i Python";

thePlugins.get("_cloudflare").langLoaded();
