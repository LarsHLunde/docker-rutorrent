﻿/* PLUGIN _CLOUDFLARE
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare plugin: Módulo cloudscraper não pode ser carregado em Python";

thePlugins.get("_cloudflare").langLoaded();
