﻿/*
 * PLUGIN COOKIES
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.cookiesDesc		= "쿠키 (형식: 호스트|쿠키1;쿠키2...)";
 theUILang.cookiesName		= "쿠키";

thePlugins.get("cookies").langLoaded();
