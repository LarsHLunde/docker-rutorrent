﻿/*
 * PLUGIN COOKIES
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.cookiesDesc		= "Çerezler (Format: host|çerez1;çerez2...)";
 theUILang.cookiesName		= "Çerezler";

thePlugins.get("cookies").langLoaded();
