﻿/*
 * PLUGIN COOKIES
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.cookiesDesc		= "Cookies (Formato: anfitrião|cookie1;cookie2...)";
 theUILang.cookiesName		= "Cookies";

thePlugins.get("cookies").langLoaded();