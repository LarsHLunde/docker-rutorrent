﻿/*
 * PLUGIN CREATE
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "Criar Torrent...";
 theUILang.CreateNewTorrent		= "Criar Novo Torrent";
 theUILang.SelectSource			= "Selecionar Fonte";
 theUILang.TorrentProperties		= "Propriedades do Torrent";
 theUILang.PieceSize			= "Tamanho das peças";
 theUILang.Other			= "Outros";
 theUILang.StartSeeding			= "Começar a semear";
 theUILang.PrivateTorrent		= "Torrent privado";
 theUILang.torrentCreate		= "Criar...";
 theUILang.BadTorrentData		= "Deve preencher todos os campos obrigatórios!";
 theUILang.createExternalNotFound	= "Create plugin: O plug-in não funcionará. O utilizador do servidor Web não pode aceder ao programa externo";
 theUILang.incorrectDirectory		= "Diretório incorreto";
 theUILang.cantExecExternal		= "Não é possível executar o programa externo";
 theUILang.createConsole		= "Consola";
 theUILang.createErrors			= "Erros";
 theUILang.torrentSave			= "Guardar";
 theUILang.torrentKill			= "Parar";
 theUILang.torrentKilled		= "O processo foi parado.";
 theUILang.recentTrackers		= "Rastreadores recentes";
 theUILang.source			    = "Fonte";
 theUILang.HybridTorrent		= "Torrent híbrido";
 theUILang.deleteFromRecentTrackers	= "> Apagar";

thePlugins.get("create").langLoaded();