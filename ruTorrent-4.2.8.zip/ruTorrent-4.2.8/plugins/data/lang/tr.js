﻿/*
 * PLUGIN DATA
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.getData		= "Dosyayı Al";
 theUILang.cantAccessData	= "Web sunucusu kullanıcısı bu torrentin verilerine erişemez.";

thePlugins.get("data").langLoaded();
