﻿/*
 * PLUGIN DATA
 *
 * Portuguese (Portugal) language file.
 *
 * Author: 
 */

 theUILang.getData		= "Obter ficheiro";
 theUILang.cantAccessData	= "O utilizador do servidor web não pode aceder aos dados deste torrent.";

thePlugins.get("data").langLoaded();