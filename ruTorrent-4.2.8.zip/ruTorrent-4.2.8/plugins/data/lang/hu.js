/*
 * PLUGIN DATA
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.getData		= "Fájl letöltése";
 theUILang.cantAccessData	= "A webszerver felhasználó nem tud hozzáférni a torrent adataihoz.";

thePlugins.get("data").langLoaded();
