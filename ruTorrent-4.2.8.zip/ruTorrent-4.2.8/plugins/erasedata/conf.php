<?php

	// interval for schedule command of garbage checker in seconds
	$garbageCheckInterval = 15;
	$enableForceDeletion = false;

	$erasedebug_enabled = false;
	
	// Replaces "remove" option in torrent menu to always delete with data
	// Refrains from showing other options on web interface
	$replaceRemoveTorrent = false;
