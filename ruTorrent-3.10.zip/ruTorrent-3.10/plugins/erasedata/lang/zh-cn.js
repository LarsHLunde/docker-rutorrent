﻿/*
 * PLUGIN ERASEDATA
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.Rem_torrents_content_prompt		= "你真的想移除选中的 torrent(s) 吗? 警告: 这将删除 torrent 的内容.";
 theUILang.Delete_data_with_path		= "删除目录";
 theUILang.Rem_torrents_with_path_prompt	= "你真的想移除选中的 torrent(s) 吗? 警告: 这将删除torrent 当前文件夹内的所有文件.";

thePlugins.get("erasedata").langLoaded();
