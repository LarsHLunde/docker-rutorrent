﻿/*
 * PLUGIN ERASEDATA
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.Rem_torrents_content_prompt		= "Θέλετε πραγματικά να διαγράψετε το(α) επιλεγμένο(α) torrent; ΠΡΟΣΟΧΗ: Αυτό θα διαγράψει τα περιεχόμενα του torrent.";
 theUILang.Delete_data_with_path		= "Διαγραφή Διαδρομής";
 theUILang.Rem_torrents_with_path_prompt	= "Θέλετε πραγματικά να διαγράψετε το(α) επιλεγμένο(α) torrent; ΠΡΟΣΟΧΗ: Αυτό θα διαγράψει όλα τα αρχεία στον τρέχων φάκελο αυτού του torrent.";

thePlugins.get("erasedata").langLoaded();