<?php

	// interval for schedule command of garbage checker in seconds
	$garbageCheckInterval = 15;
	$enableForceDeletion = false;

	$erasedebug_enabled = false;
