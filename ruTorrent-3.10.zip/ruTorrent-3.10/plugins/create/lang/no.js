﻿/*
 * PLUGIN CREATE
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.mnu_create			= "Lag Torrent...";
 theUILang.CreateNewTorrent		= "Lag Ny Torrent";
 theUILang.SelectSource			= "Velg Kilde";
 theUILang.TorrentProperties		= "Torrentegenskaper";
 theUILang.PieceSize			= "Delstørrelse";
 theUILang.Other			= "Annet";
 theUILang.StartSeeding			= "Start seeding";
 theUILang.PrivateTorrent		= "Privat torrent";
 theUILang.torrentCreate		= "Lag...";
 theUILang.BadTorrentData		= "Du må fylle ut alle påkrevde felt!";
 theUILang.createExternalNotFound	= "Create plugin: Plugin vil ikke funke. Webserverbrukeren får ikke tilgang til eksternt program";
 theUILang.incorrectDirectory		= "Ugyldig mappe";
 theUILang.cantExecExternal		= "Kan ikke kjøre eksternt program";
 theUILang.createConsole		= "Konsoll";
 theUILang.createErrors			= "Feilmeldinger";
 theUILang.torrentSave			= "Lagre";
 theUILang.torrentKill			= "Stopp";
 theUILang.torrentKilled		= "Prosessen ble stoppet.";
 theUILang.recentTrackers		= "Siste trackere";
 theUILang.source			= "Source";

thePlugins.get("create").langLoaded();