﻿/*
 * PLUGIN DISKSPACE
 *
 * Portuguese language file.
 *
 * Author: 
 */

 theUILang.diskNotification	= "Warning! The disk is full. rTorrent may not run correctly, and no data will be downloaded until you free some disk space.";

thePlugins.get("diskspace").langLoaded();