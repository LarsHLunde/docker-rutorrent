﻿/*
 * PLUGIN COOKIES
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.cookiesDesc		= "Cookies (Μορφή: διακομιστής|cookie1;cookie2...)";
 theUILang.cookiesName		= "Cookies";

thePlugins.get("cookies").langLoaded();