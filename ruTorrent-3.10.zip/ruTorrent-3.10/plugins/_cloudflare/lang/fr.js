﻿/* PLUGIN _CLOUDFLARE
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare plugin: Le module cloudscraper ne peut pas être chargé dans Python";

thePlugins.get("_cloudflare").langLoaded();
