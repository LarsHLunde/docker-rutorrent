﻿/*
 * PLUGIN DATA
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.getData		= "파일 받기";
 theUILang.cantAccessData	= "웹서버 사용자가 이 토렌트의 데이터에 접근할 수 없습니다.";

thePlugins.get("data").langLoaded();
